// 1. APPLICATION STATE
// - Holds the state of the application
// - This is the single source of truth for the application state

const state = {
    men: {
      manga: ["mangamen1.jpg", "mangamen2.jpg"],
      manhwa: ["manhwamen1.jpg", "manhwamen2.jpg"],
      "ai-art": ["ai-artmen1.jpg", "ai-artmen2.jpg"]
    },
    animal: {
      manga: ["mangaanimal1.jpg", "mangaanimal2.jpg"],
      manhwa: ["manhwaanimal1.jpg", "manhwaanimal2.jpg"],
      "ai-art": ["ai-artanimal1.jpg", "ai-artanimal2.jpg"]
    },
    women: {
      manga: ["mangawomen1.jpg", "mangawomen2.jpg"],
      manhwa: ["manhwawomen1.jpg", "manhwawomen2.jpg"],
      "ai-art": ["ai-artwomen1.jpg", "ai-artwomen2.jpg"]
    },
    girl: {
      manga: ["mangagirl1.jpg", "mangagirl2.jpg"],
      manhwa: ["manhwagirl1.jpg", "manhwagirl2.jpg"],
      "ai-art": ["ai-artgirl1.jpg", "ai-artgirl2.jpg"]
    },
    boy: {
      manga: ["mangaboy1.jpg", "mangaboy2.jpg"],
      manhwa: ["manhwaboy1.jpg", "manhwaboy2.jpg"],
      "ai-art": ["ai-artboy1.jpg", "ai-artboy2.jpg"]
    }
  };
  
  // 2. STATE ACCESSORS/MUTATORS FN'S
  // - Functions that allow us to get and set the state
  
  function getSelectedImages(artStyle, characteristic, extra) {
    if (extra === 'full-colour') {
      if (artStyle === 'manhwa' || artStyle === 'ai-art') {
        return state[characteristic][artStyle] || [];
      }
    } else if (extra === 'no-colour') {
      if (artStyle === 'manga') {
        return state[characteristic][artStyle] || [];
      }
    } else {
      return state[characteristic][artStyle] || [];
    }
    return [];
  }
  
  // 3. DOM Node Refs
  // - Static references to DOM nodes needed after the start of the application
  
  const artStyleSelect = document.getElementById('art-style');
  const characteristicsSelect = document.getElementById('characteristics');
  const extraSelect = document.getElementById('extra');
  const deleteButton = document.getElementById('delete');
  const continueButton = document.getElementById('continue');
  const imageContainer = document.getElementById('image-container');
  
  // 4. DOM Node Creation Fn's
  // - Dynamic creation of DOM nodes needed upon user interaction
  
  function createImageElement(src) {
    const img = document.createElement('img');
    img.src = `images2/${src}`; // Updated to point to images2 folder
    img.alt = src;
    return img;
  }
  
  // 5. RENDER FN
  // - These functions will render the application state to the DOM
  
  function renderImages(images) {
    imageContainer.innerHTML = '';
    images.forEach(src => {
      const img = createImageElement(src);
      imageContainer.appendChild(img);
    });
  }
  
  // 6. EVENT HANDLERS
  // - These functions handle user interaction
  
  function onDeleteButtonClicked() {
    artStyleSelect.value = '';
    characteristicsSelect.value = '';
    extraSelect.value = '';
    imageContainer.innerHTML = '';
  }
  
  function onContinueButtonClicked() {
    const artStyle = artStyleSelect.value;
    const characteristic = characteristicsSelect.value;
    const extra = extraSelect.value;
    const images = getSelectedImages(artStyle, characteristic, extra);
    renderImages(images);
  }
  
  // 7. INIT BINDINGS
  // - These are the initial bindings of the event handlers
  
  deleteButton.addEventListener('click', onDeleteButtonClicked);
  continueButton.addEventListener('click', onContinueButtonClicked);
  
  // 8. INITIAL RENDER
  // - Initial rendering of the state
  
  function init() {
    renderImages([]);
  }
  
  init();
  